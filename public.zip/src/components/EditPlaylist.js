import React from "react";
import { Link } from "react-router-dom";
import Sidebar from "./Sidebar";

const EditPlaylist = () =>{
    return(
        <>
            <Sidebar/>
            <div className="vh_dashboard_wrapper">            
                <div className="vh_dashboard_heading_parent">
                    <div className="vh_dashboard_heading_left">
                        <h4>edit playlist</h4>
                    </div>                    
                </div>
                <div className="vh_edt_header_btns">
                    <ul>
                       <li>
                            <Link to=""><span>01</span>title & settings</Link>
                       </li>
                       <li>
                            <Link to=""><span>02</span>choose campaign</Link>
                       </li>
                       <li>
                            <Link to=""><span>03</span>preview</Link>
                       </li>  
                    </ul>
                </div>            
            </div>
        </>
    )
};



export default EditPlaylist
